function calendarButton() {
  window.location.assign("calendar.html");
}

function formButton() {
  window.location.assign("form.html");
}